import requests
from bs4 import BeautifulSoup
import fitz  # PyMuPDF
import io
import pandas as pd
import tempfile
import os
import csv  # Import csv module for quoting options

# Function to get all PDF links from a main URL
def get_pdf_links(main_url):
    response = requests.get(main_url)
    soup = BeautifulSoup(response.content, 'html.parser')
    
    # Find all links ending with .pdf
    pdf_links = []
    for link in soup.find_all('a', href=True):
        if link['href'].endswith('.pdf'):
            pdf_links.append(link['href'])
            if len(pdf_links) >= 500:  # Limit to first 500 PDF links
                break
    
    return pdf_links

# Function to extract text from a PDF file using PyMuPDF
def extract_text_from_pdf(pdf_url):
    response = requests.get(pdf_url)
    pdf_file = io.BytesIO(response.content)

    # Create a temporary file to hold the PDF
    with tempfile.NamedTemporaryFile(delete=False, suffix='.pdf') as temp_pdf:
        temp_pdf.write(pdf_file.getvalue())
        temp_pdf_path = temp_pdf.name

    # Open the temporary PDF file with fitz
    try:
        doc = fitz.open(temp_pdf_path)  
        text = []
        
        for page in doc:
            text.append(page.get_text())  # Extract text from each page

    finally:
        # Ensure the document is closed before deleting the temporary file
        doc.close()
        os.remove(temp_pdf_path)  # Remove the temp file after reading

    return "\n".join(text)  # Join all pages into a single string

# Main URL from which to scrape PDF links
main_url = 'https://archive.org/details/in.gazette.central.w.2000-09-30.153'

# Get all PDF links from the main URL
pdf_links = get_pdf_links(main_url)

# Create a list to store the extracted data
data = []

# Extract text from each PDF and store it in the list
for pdf_link in pdf_links:
    # Check if the link is relative and construct full URL if necessary
    if not pdf_link.startswith('http'):
        pdf_link = 'https://archive.org' + pdf_link
        
    print(f"Extracting text from: {pdf_link}")
    pdf_text = extract_text_from_pdf(pdf_link)
    
    # Append the PDF link and its extracted text to the data list
    data.append({
        'PDF Link': pdf_link,
        'Extracted Text': pdf_text
    })

# Create a DataFrame from the extracted data
df = pd.DataFrame(data)

# Clean up the DataFrame for better output
df['Extracted Text'] = df['Extracted Text'].replace('', float('nan'))  # Replace empty strings with NaN
df.dropna(subset=['Extracted Text'], inplace=True)  # Drop rows where 'Extracted Text' is NaN

# Display the DataFrame
print(df.head())  # Print the first few rows of the DataFrame

# Save the DataFrame to a Notepad file (text file)
df.to_csv('scraped_pdf_data.txt', index=False, quoting=csv.QUOTE_NONNUMERIC, sep='\t')  # Use tab separator for better readability
print("Data saved to 'scraped_pdf_data.txt'")
