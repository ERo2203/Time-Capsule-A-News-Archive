from flask import Flask, request, jsonify, render_template
from transformers import pipeline
import json
import logging
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

# Database configuration for MySQL
app.config['SQLALCHEMY_DATABASE_URI'] = 'mysql+mysqlconnector://username:1234567890@localhost/qa_pairs'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

# Define the model for the QA pairs
class QAPair(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    context = db.Column(db.Text, nullable=False)
    question = db.Column(db.String(255), nullable=False)
    answer = db.Column(db.Text, nullable=False)

    def __repr__(self):
        return f"<QAPair {self.question}>"

# Load the question-answering model
qa_pipeline = pipeline("question-answering", model="distilbert-base-cased-distilled-squad")

@app.before_first_request
def create_tables():
    db.create_all()  # Create tables if they don't exist

@app.before_first_request
def load_data_into_db():
    # Load data from JSON into the database (optional)
    with open('C:\\Users\\D ARUNA PRIYA\\OneDrive\\Desktop\\BTech\\Projects\\Applicative Project - 1\\summaries.json', 'r') as f:
        data = json.load(f)

    for item in data:
        qa_pair = QAPair(context=item['context'], question=item['question'], answer=item['answer'])
        db.session.add(qa_pair)
    db.session.commit()

@app.route('/')
def home():
    return render_template('index.html')  # Ensure this matches the HTML filename

@app.route('/questions')
def questions():
    return render_template('questions.html')

@app.route('/ask', methods=['POST'])
def answer_question():
    user_question = request.json.get('question', '')
    if not user_question:
        return jsonify({'error': 'Question is required.'}), 400

    best_answer = None
    highest_score = 0.0

    # Retrieve all QA pairs from the database
    qa_pairs = QAPair.query.all()

    for qa in qa_pairs:
        context = qa.context
        result = qa_pipeline(question=user_question, context=context)

        if result['score'] > highest_score:
            highest_score = result['score']
            best_answer = result['answer']

    logging.info(f'User question: {user_question}, Best answer: {best_answer}')
    return jsonify({'answer': best_answer if best_answer else "Sorry, I couldn't find an answer."})

if __name__ == '__main__':
    app.run(debug=True)
