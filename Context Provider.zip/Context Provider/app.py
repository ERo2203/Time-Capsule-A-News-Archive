from flask import Flask, request, jsonify, render_template
from transformers import pipeline
import json
import logging

app = Flask(__name__)
logging.basicConfig(level=logging.INFO)

# Load the JSON file
with open('C:\\Users\\D ARUNA PRIYA\\OneDrive\\Desktop\\BTech\\Projects\\Applicative Project - 1\\summaries.json', 'r') as f:
    data = json.load(f)

# Load the question-answering model
qa_pipeline = pipeline("question-answering")

@app.route('/')
def home():
    return render_template('index.html')  # Ensure this matches the HTML filename

@app.route('/questions')
def questions():
    return render_template('questions.html')

@app.route('/ask', methods=['POST'])
def answer_question():
    user_question = request.json.get('question', '')
    if not user_question:
        return jsonify({'error': 'Question is required.'}), 400

    best_answer = None
    highest_score = 0.0

    for item in data:
        context = item['context']
        result = qa_pipeline(question=user_question, context=context)

        if result['score'] > highest_score:
            highest_score = result['score']
            best_answer = result['answer']

    logging.info(f'User question: {user_question}, Best answer: {best_answer}')
    return jsonify({'answer': best_answer if best_answer else "Sorry, I couldn't find an answer."})

if __name__ == '__main__':
    app.run(debug=True)
    

