from flask import Flask, request, jsonify, render_template
from transformers import DistilBertForSequenceClassification, DistilBertTokenizer
import json
import os

app = Flask(__name__)

# Load the fine-tuned model and tokenizer
tokenizer = DistilBertTokenizer.from_pretrained("/Users/rohanrao/TimeMachine/fine_tuned_distilbert")
model = DistilBertForSequenceClassification.from_pretrained("/Users/rohanrao/TimeMachine/fine_tuned_distilbert")

# Load and limit data
DATA_PATH = '/Users/rohanrao/TimeMachine/myData.json'
SAMPLE_SIZE = 1000

with open(DATA_PATH, 'r') as f:
    data = json.load(f)[:SAMPLE_SIZE]  # Limit to SAMPLE_SIZE entries

@app.route('/')
def home():
    return render_template('index.html')  # Ensure index.html is in the templates folder

@app.route('/extract', methods=['POST'])
def extract():
    req_data = request.get_json()
    topic = req_data.get('topic', '')
    year = req_data.get('year', '')

    # Filter data based on topic and year
    filtered_data = [
        entry for entry in data
        if entry['topic'].lower() == topic.lower() and entry['published_date'].startswith(str(year))
    ]

    # Prepare results
    results = [{"title": entry['title'], "link": entry['link'], "date": entry['published_date']} for entry in filtered_data]

    # Return results or error if empty
    if not results:
        return jsonify({"error": "No results found."})
    return jsonify(results)

if __name__ == '__main__':
    app.run(debug=True)
