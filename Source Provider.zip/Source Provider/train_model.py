from transformers import DistilBertForSequenceClassification, Trainer, TrainingArguments, DistilBertTokenizer
from torch.utils.data import Dataset
import torch
import json

# Constants
DATA_PATH = '/Users/rohanrao/TimeMachine/myData.json'
SAMPLE_SIZE = 1000  # Limit number of entries

# Check CUDA availability
print(torch.cuda.is_available())  # Should return True if CUDA is set up correctly

# Load tokenizer and model
tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")
model = DistilBertForSequenceClassification.from_pretrained("distilbert-base-uncased", num_labels=2)

# Load data
def load_data():
    with open(DATA_PATH, 'r') as f:
        data = json.load(f)
    return data[:SAMPLE_SIZE]

# Custom dataset class
class NewsDataset(Dataset):
    def __init__(self, data, tokenizer):
        self.data = data
        self.tokenizer = tokenizer
    
    def __len__(self):
        return len(self.data)
    
    def __getitem__(self, idx):
        entry = self.data[idx]
        title = entry['title']
        
        # Tokenize the title text
        inputs = self.tokenizer(
            title,
            padding='max_length',
            truncation=True,
            max_length=64,
            return_tensors="pt"
        )
        
        # Sample label (0 or 1) for demonstration purposes; set according to your task
        label = torch.tensor(0)  # Replace with actual label if available
        
        # Return dictionary with squeezed tensors to remove extra dimension
        return {
            "input_ids": inputs['input_ids'].squeeze(),
            "attention_mask": inputs['attention_mask'].squeeze(),
            "labels": label
        }

# Prepare data and dataset
data = load_data()
dataset = NewsDataset(data, tokenizer)

# Training function
def train_model():
    # Training arguments
    training_args = TrainingArguments(
        output_dir="./fine_tuned_distilbert",
        num_train_epochs=2,
        per_device_train_batch_size=16,
        logging_dir="./logs",
        save_steps=10_000,
        save_total_limit=2
    )
    
    # Trainer setup
    trainer = Trainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
    )
    
    # Train the model
    trainer.train()
    
    # Save the fine-tuned model and tokenizer
    model.save_pretrained("./fine_tuned_distilbert")
    tokenizer.save_pretrained("./fine_tuned_distilbert")

# Run training
if __name__ == "__main__":
    train_model()
