from transformers import DistilBertForSequenceClassification, Trainer, TrainingArguments, DistilBertTokenizer
import torch
from datasets import load_dataset

# Load your dataset (using MRPC as an example)
dataset = load_dataset('glue', 'mrpc')

# Load the pre-trained model with a classification head
model = DistilBertForSequenceClassification.from_pretrained('distilbert-base-uncased', num_labels=2)

# Load the tokenizer
tokenizer = DistilBertTokenizer.from_pretrained('distilbert-base-uncased')

# Tokenize the dataset
def tokenize_function(examples):
    return tokenizer(examples['sentence1'], examples['sentence2'], padding="max_length", truncation=True)

tokenized_datasets = dataset.map(tokenize_function, batched=True)

# Sample smaller datasets for quick testing (optional)
small_train_dataset = tokenized_datasets["train"].shuffle(seed=42).select(range(int(0.01 * len(tokenized_datasets["train"]))))
small_eval_dataset = tokenized_datasets["validation"].shuffle(seed=42).select(range(int(0.01 * len(tokenized_datasets["validation"]))))
  
# Set training arguments without fp16 for compatibility with MPS and updated eval_strategy
training_args = TrainingArguments(
    output_dir="./results",
    eval_strategy="epoch",  # Updated from evaluation_strategy for future compatibility
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=1,
    weight_decay=0.01,
    fp16=False,  # Disabled for non-GPU device
)

# Define the Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=small_train_dataset,
    eval_dataset=small_eval_dataset,
)

# Train the model
trainer.train()

# Save the model and tokenizer
model.save_pretrained("./fine_tuned_distilbert")
tokenizer.save_pretrained("./fine_tuned_distilbert")
