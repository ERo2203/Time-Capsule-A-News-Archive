import json
from transformers import DistilBertTokenizer
import torch

# Path to your JSON file
DATA_PATH = '/Users/rohanrao/TimeMachine/myData.json'
SAMPLE_SIZE = 1000  # Limit the number of entries for loading and training

def load_data():
    # Load JSON data with a limit on the number of entries
    with open(DATA_PATH, 'r') as f:
        data = json.load(f)
    return data[:SAMPLE_SIZE]  # Limit to SAMPLE_SIZE entries

def filter_data(data, topic, year):
    # Filter entries based on topic and year
    filtered_data = [
        entry for entry in data
        if entry['topic'].lower() == topic.lower() and entry['published_date'].startswith(str(year))
    ]
    return filtered_data

# Initialize the DistilBERT tokenizer
tokenizer = DistilBertTokenizer.from_pretrained("distilbert-base-uncased")

# Function to tokenize data for training
def tokenize_data(data):
    return tokenizer(
        [entry['title'] for entry in data],
        padding=True,
        truncation=True,
        return_tensors='pt'
    )

# Add labels to your data for training (e.g., for classification)
def get_labels(data):
    topics = list(set(entry['topic'] for entry in data))  # Extract unique topics
    label_map = {topic: idx for idx, topic in enumerate(topics)}  # Map topics to label indices

    labels = [label_map[entry['topic']] for entry in data]  # Convert topics to label indices
    return torch.tensor(labels)

# Example Usage
if __name__ == "__main__":
    # Load and filter data
    data = load_data()
    filtered_data = filter_data(data, 'HEALTH', 2020)

    # Tokenize titles and get labels
    tokenized_data = tokenize_data(filtered_data)
    labels = get_labels(filtered_data)

    print(tokenized_data)
    print(labels)
